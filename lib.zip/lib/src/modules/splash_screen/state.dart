class SplashScreenState {
  SplashScreenState() {
    ///Initialize variables
  }
}
