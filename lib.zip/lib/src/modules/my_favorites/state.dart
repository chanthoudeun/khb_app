class MyFavoritesState {
  MyFavoritesState() {
    ///Initialize variables
  }
}
