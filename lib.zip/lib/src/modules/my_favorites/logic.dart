import 'package:get/get.dart';

import 'state.dart';

class MyFavoritesLogic extends GetxController {
  final MyFavoritesState state = MyFavoritesState();
}
