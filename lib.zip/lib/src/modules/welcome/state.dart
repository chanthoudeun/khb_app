class WelcomeState {
  WelcomeState() {
    ///Initialize variables
  }
}
