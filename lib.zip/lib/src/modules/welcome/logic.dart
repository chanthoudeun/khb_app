import 'package:get/get.dart';

import '../../../core/app/logic.dart';
import '../../route/app_navigation.dart';
import 'state.dart';

class WelcomeLogic extends GetxController {
  final WelcomeState state = WelcomeState();

  @override
  Future<void> onInit() async {
    super.onInit();
  }
}
