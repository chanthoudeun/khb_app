import 'package:get/get.dart';

import 'state.dart';

class TermConditionLogic extends GetxController {
  final TermConditionState state = TermConditionState();
}
