class TermConditionState {
  TermConditionState() {
    ///Initialize variables
  }
}
