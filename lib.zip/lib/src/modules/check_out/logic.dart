import 'package:get/get.dart';

import 'state.dart';

class CheckOutLogic extends GetxController {
  final CheckOutState state = CheckOutState();
}
