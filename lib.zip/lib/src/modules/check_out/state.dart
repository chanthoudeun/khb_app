class CheckOutState {
  CheckOutState() {
    ///Initialize variables
  }
}
