import 'package:get/get.dart';

import 'state.dart';

class OrderDetailLogic extends GetxController {
  final OrderDetailState state = OrderDetailState();
}
