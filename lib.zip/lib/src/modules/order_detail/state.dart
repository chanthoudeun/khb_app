class OrderDetailState {
  OrderDetailState() {
    ///Initialize variables
  }
}
