class ProductDetailState {
  ProductDetailState() {
    ///Initialize variables
  }
}
