import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'logic.dart';

class ProductDetailPage extends StatelessWidget {
  final logic = Get.put(ProductDetailLogic());
  final state = Get.find<ProductDetailLogic>().state;

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
