class MyCartState {
  MyCartState() {
    ///Initialize variables
  }
}
