import 'package:get/get.dart';

import 'state.dart';

class MyCartLogic extends GetxController {
  final MyCartState state = MyCartState();
}
