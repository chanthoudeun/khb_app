// GENERATED CODE - DO NOT MODIFY BY HAND

part of '../en.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$EnImpl _$$EnImplFromJson(Map<String, dynamic> json) => _$EnImpl(
      name: json['name'] as String?,
      message: json['message'] as String?,
    );

Map<String, dynamic> _$$EnImplToJson(_$EnImpl instance) => <String, dynamic>{
      'name': instance.name,
      'message': instance.message,
    };
