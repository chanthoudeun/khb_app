// GENERATED CODE - DO NOT MODIFY BY HAND

part of '../km.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$KmImpl _$$KmImplFromJson(Map<String, dynamic> json) => _$KmImpl(
      name: json['name'] as String?,
    );

Map<String, dynamic> _$$KmImplToJson(_$KmImpl instance) => <String, dynamic>{
      'name': instance.name,
    };
