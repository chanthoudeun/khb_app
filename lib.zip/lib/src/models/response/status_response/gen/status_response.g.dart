// GENERATED CODE - DO NOT MODIFY BY HAND

part of '../status_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$StatusResponseImpl _$$StatusResponseImplFromJson(Map<String, dynamic> json) =>
    _$StatusResponseImpl(
      name: json['name'] as String?,
      value: json['value'] as String?,
    );

Map<String, dynamic> _$$StatusResponseImplToJson(
        _$StatusResponseImpl instance) =>
    <String, dynamic>{
      'name': instance.name,
      'value': instance.value,
    };
