enum AuthEndpoint {
  LOGIN,
  GET_TOKEN,
}

enum BannerEndpoint {
  GET_ALL,
}

enum ProductEndpoint {
  GET_ALL,
}

enum PurchaseOrderEndpoint {
  GET_ALL,
}

enum NotificationEndpoint {
  GET_ALL,
}

enum OutletDetailEndpoint {
  GET_BY_ID,
}

enum DeleteUserAccountEndpoint {
  DELETE_ACCOUNT,
}
