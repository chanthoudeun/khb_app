class AppTagHero {
  /// Product tag
  static String get tag1 => "1";
}
