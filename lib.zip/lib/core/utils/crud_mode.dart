enum CrudMode {
  EMPTY,
  CREATE,
  READ,
  UPDATE,
  DELETE,
}
