class AppConst {
  static String englishSuperMarketFont = "Montserrat";
  static String englishFontMall = "SF Pro Display";
  static String khmerFont = "Krasar";
  static String englishCode = "en";
  static String khmerCode = "kh";
}
