class StorageKey {
  //region App Setting
  static String settingBox = "setting_storage_box";
  static String settingData = "setting_data";

  //endregion

  // region User
  static String userBox = "user_storage_box";
  static String userData = "user_data";

  //endregion

  // region User
  static String itemBox = "item_storage_box";
  static String itemData = "item_data";

//endregion

  static String favoriteProductBox = "favorite_box";
  static String favoriteProductData = "favorite_product_data";

  // region Search Mall
  static String searchHistoryBox = "search_history_storage_box";
  static String searchHistoryData = "search_history_data";

//endregion

// region Theme Mall
  static String themeBox = "theme_storage_box";
  static String themeData = "theme_data";
//endregion
}
